/**
 * 
 */
package itech2306package1;

/**
 * @author kkeogh
 *
 */
public class Person {
	String name;
	String postcode;
	String address;
	Animal pet;
	/**
	 * @return the name
	 */
	public String getName() {
		return name;
	}
	/**
	 * @param name the name to set
	 */
	public void setName(String name) {
		this.name = name;
	}
	/**
	 * @return the address
	 */
	public String getAddress() {
		return address;
	}
	/**
	 * @param address the address to set
	 */
	public void setAddress(String address) {
		this.address = address;
	}
	
	public String getPostcode()
	{
		return postcode;
	}
	public void setPostcode(String postcode)
	{
		this.postcode=postcode;
	}
	Person (String _address, String _name, String _postcode)
	{
	this.setAddress(_address);
	this.setName (_name);
	this.setPostcode (_postcode);
	}
	void addAPet(Animal _pet) {
		this.pet = _pet;
		}
	/**
	 * @param args
	 */
	public static void main(String[] args) {
		Person p= new Person("75 Boundary\r\n" + 
				"street, SomeSuburb","Peter","88668866");
		Animal myPet = new Animal(); 
		myPet.setName("Beta");
		myPet.setAge("2 years old-01/10/2018");
		myPet.setBreed("Cat");
		p.addAPet(myPet);
		String PersonAndPet=p.toString();
		System.out.println(PersonAndPet);
		
	}

}
